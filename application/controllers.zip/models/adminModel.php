<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class AdminModel extends CI_Model {
    public function register_User($firstname,$lastname,$email,$type,$contact_number,$password,$image_url){

        $data = array(
            'first_name'=>$firstname,
            'last_name'=>$lastname,
            'email'=>$email,
            'type'=>$type,
            'contact_number'=>$contact_number,
            'img_url'=>$image_url
        );

        $this->db->insert('user',$data);

        return ($this->db->affected_rows() != 1) ? false : true;
    }
    public function delete_User($user_id){

        $this->db->where('id', $user_id);
        $this->db->delete('user');
        return;
    }
    public function edit_User($user_id){
        $this->db->where('id', $user_id);
        $this->db->select('id,first_name,last_name,email,type,contact_number');
        $user_data = $this->db->get('user');
        if($user_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result()
            // if you want to store them as an array you can use $q->result_array()
            foreach ($user_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }
    }
    public function edit_User_Final($id,$firstname,$lastname,$email,$type,$contact_number,$password,$image_url){

        $data = array(
            'firstname'=>$firstname,
            'lastname'=>$lastname,
            'email'=>$email,
            'type'=>$type,
            'contact_number'=>$contact_number,
            'password'=>$password,
            'image_url'=>$image_url
        );
        $this->db->where('id', $id);
        $this->db->update('user_details', $data);
        return ($this->db->affected_rows() != 1) ? false : true;
    }

    //Assign User to database
    public function assign_User($uid,$username,$password,$type){
        $data = array(
            'user_id'=>$uid,
            'username'=>$username,
            'password'=>$password,
            'type'=>$type,

        );

        $this->db->insert('user_role',$data);

        return ($this->db->affected_rows() != 1) ? false : true;
    }
    public function assign_ExUserwithPassword($uid,$username,$password){

        $data = array(
            'uid'=>$uid,
            'userName'=>$username,
            'password'=>$password,

        );
        $this->db->where('userName', $username);
        $this->db->update('user', $data);
        return ($this->db->affected_rows() != 1) ? false : true;
    }

    public function select()
    {
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get('user_details');
        return $query;
    }

    public function insert($data)
    {
        $this->db->insert_batch('student', $data);
        return $this->db->insert_id();
    }
    public function insert_additional_data($data){

        $this->db->insert_batch('student_ex', $data);
    }
    public function selectForms(){

        $this->db->select('title,id');
        $user_data = $this->db->get('form');
        if($user_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result()
            // if you want to store them as an array you can use $q->result_array()
            foreach ($user_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }
    }
    public function createEvent($name,$date,$venue,$file_name){

        $data = array(
            'title'=>$name,
            'date'=>$date,
            'venue'=>$venue,
            'form_id'=>$file_name,

        );

        $this->db->insert('events',$data);

        return ($this->db->affected_rows() != 1) ? false : true;
    }
    //get all keys for the perticular form
    public function getKeys($form_id){
        $this->db->select('keys_table.name');
        $this->db->from('keys_table');
        $this->db->join('form_field','form_field.key_id=keys_table.id','Left');
        $this->db->where('form_field.form_id', $form_id);
        return $this->db->get();


    }
    //Get the Foem Name
    public function getFormName($form_id){
        $this->db->where('id',$form_id);
        $this->db->select('title');
        $user_data = $this->db->get('form');
        if($user_data->num_rows() > 0)
        {
            return $user_data->row(0)->title;
        }
        return false;
    }
    //To get all the Form Fields of selected form
    public function getFormFields($form_id){

        $this->db->select('keys_table.name,form_element.id,element.title,form_element.options');
        $this->db->from('keys_table');
        $this->db->join('form_field','form_field.key_id=keys_table.id');
        $this->db->join('form_element','form_element.id=keys_table.form_element_id');
        $this->db->join('element','element.id=form_element.element_id');
        $this->db->where('form_field.form_id', $form_id);


//        $this->db->select('key_id');
//        $this->db->where('form_id', $form_id);
        $key_data = $this->db->get();



        if($key_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result()
            // if you want to store them as an array you can use $q->result_array()
            foreach ($key_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }
    }

    public function get_Additional_Fields($form_id){
        $this->db->select('keys_table.name');
        $this->db->from('keys_table');
        $this->db->join('form_field','form_field.key_id=keys_table.id');
        $this->db->where('form_field.form_id', $form_id);
        $key_data = $this->db->get();


        if($key_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result()
            // if you want to store them as an array you can use $q->result_array()
            foreach ($key_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }



    }
    public function add_Student_Data($first_name,$last_name,$email,$mobile_number,$residence_number,$address,$event_id){
        $data = array(
            'first_name'=>$first_name,
            'last_name'=>$last_name,
            'email'=>$email,
            'mobile_number'=>$mobile_number,
            'residence_number'=>$residence_number,
            'address'=>$address,
            'event_id'=> $event_id
        );

        $this->db->insert('student',$data);
        return $this->db->insert_id();
    }

    public function add_Student_Ex_Data($count,$var1,$value,$insertion_type){
        $data = array(
            'student_id'=>$count,
            'key'=>$var1,
            'value'=>$value,
            'type'=>$insertion_type,

        );

        $this->db->insert('student_ex',$data);
        return ($this->db->affected_rows() != 1) ? false : true;

    }

    public function check_Duplicates($mobile_number,$residence_number){

        $where = "mobile_number=$mobile_number AND residence_number=$residence_number OR mobile_number=$residence_number OR residence_number=$mobile_number";

        $this->db->where($where);
        $user_data = $this->db->get('student');
        if($user_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result().
            // if you want to store them as an array you can use $q->result_array()
            foreach ($user_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }

    }
 //Check Extra entered options from Excel and add them to options
    public function check_option($check_element_name,$check_element_value){
        $this->db->select('form_element.options,form_element.id');
        $this->db->from('form_element');
        $this->db->join('keys_table','keys_table.form_element_id=form_element.id');
        $array = array('form_element.element_id' => 2, 'keys_table.name' => $check_element_name);
        $this->db->where($array);
        $key_data = $this->db->get();
        if($key_data->num_rows() > 0){
            foreach ($key_data->result() as $row)
            {
                if (strpos($row->options, $check_element_value) !== false){

                }else{
                    $options = $row->options.','.$check_element_value;
                    $data=array('options'=>$options);
                    $this->db->where('id',$row->id);
                    $this->db->update('form_element',$data);


                }
            }
        }else{
            return 0;
        }
    }
    public function update_duplicate_fields($id,$first_name,$last_name,$email,$address){
        $data = array('first_name' => $first_name,'last_name' => $last_name, 'email' => $email , 'address'=> $address );
        $this->db->where('id', $id);
        $this->db->update('student', $data);

        return ($this->db->affected_rows() != 1) ? false : true;

    }

    public function selectFormsForEvent(){
        $this->db->select("*");
        $this->db->from("form");

        $this->db->order_by('id', 'DESC');
        $result_data =  $this->db->get();

        if($result_data->num_rows() > 0)
        {
            // we will store the results in the form of class methods by using $q->result().
            // if you want to store them as an array you can use $q->result_array()
            foreach ($result_data->result() as $row)
            {
                $data[] = $row;
            }
            return $data;
        }
    }


}



?>
